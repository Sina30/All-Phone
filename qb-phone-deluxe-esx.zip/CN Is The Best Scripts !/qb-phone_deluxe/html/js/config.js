Config = []

Config.HeaderDisabledApps = [
    "bank", 
    "whatsapp", 
    "meos", 
    "garage",
    "racing",
    "houses",
    "lawyers",
]

Config.DefaultCryptoPage = "general";