# gcphone V2.2 cracked by Jager Bom [dev]#2795

No free support will be given. If you don't figured it out how to install well then contact Jager Bom [dev]#2795 for any problems regarding but will ask as a counterpart money for my services

- unlocked phone without iplock


![alt text](https://i.imgur.com/nVLFx1L.png "Gcphone cracked by Jager Bom [dev]#2795") 
