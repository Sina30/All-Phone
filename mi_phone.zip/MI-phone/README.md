```
# MI-phone
Copy of qbus phone converted to ESX

Free Qbus Phone Fully converted to ESX
This is the first version of the phone so that maybe can be a bugs pls dm me on discord if you find one



EXTRA LEAKS 