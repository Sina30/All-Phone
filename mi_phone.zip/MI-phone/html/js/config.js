Config = []

Config.HeaderDisabledApps = [
    "bank", 
    "whatsapp", 
    "meos", 
    "garage",
    "crypto",
    "racing",
    "houses",
    "lawyers",
    "medic",
]

Config.DefaultCryptoPage = "general";