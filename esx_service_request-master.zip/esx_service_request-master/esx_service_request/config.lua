Config = {}

Config.Locale = 'en' -- language

Config.ControlName = 'INPUT_PICKUP'
Config.ControlCode = 38 -- Press [E] to accept the call
Config.AcceptTime = 10000 -- 10 seconds to accept the call
Config.BlipRadius = 10.0
