Locales['en'] = {
    ['accept']  = 'Press ~%s~ to accept the call.',

    ['take']    = '~g~You accepted the call. ~s~The local has been marked in your GPS.',
    ['fail']    = '~r~Another person already take the call.',

    ['done']    = '~g~Someone accepted the call. ~s~Wait where you are.',
    ['waiting'] = 'Your call has been sent...',
    ['nobody']  = '~r~No one was available to answer the call.',
    ['reject']  = 'Someone was available, ~r~but did not accept the call.',
}
